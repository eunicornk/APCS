function myFunction() {
  var hello= Math.floor(Math.random()*10)+1;
  console.log(hello);
  if (hello==1){
      alert ("You are going to meet the love of your life soon or you have already met the love of your life");
  }
  if (hello==2){
      alert ("You will be rich");
      
  }
  if (hello==3){
      alert ("A fresh start will put you on your way");
  }
  if (hello==4){
      alert ("A lifetime of happiness lies ahead of you");
  }
  if (hello==5){
      alert ("A wish of yours will come true today");
  }
  if (hello==6){
      alert ("A smooth long journey! Great expectations");
  }
  if (hello==7){
      alert ("Be careful or you could fall for some tricks today");
  }
  if (hello==8){
      alert ("Distance yourself from the vain");
  }
  if (hello==9){
      alert ("Disbelief destroys the magic");
  }
  if (hello==10){
      alert ("Don't just think, act!");
  }
}